/* ==============================
   Syncra TechX script.js
   Mobile-optimized version
   ============================== */

'use strict';

/* ── Scroll Progress Bar ─────────────────────────────────────── */
const scrollBar = document.getElementById('scroll-progress');
function updateScrollProgress() {
  const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
  const pct = scrollHeight - clientHeight > 0
    ? (scrollTop / (scrollHeight - clientHeight)) * 100
    : 0;
  if (scrollBar) scrollBar.style.width = `${pct}%`;
}
window.addEventListener('scroll', updateScrollProgress, { passive: true });

/* ── Mobile Nav ──────────────────────────────────────────────── */
const menuToggle = document.querySelector('.menu-toggle');
const navPanel   = document.querySelector('.nav-panel');
const navLinks   = document.querySelectorAll('.nav-links a');

function closeNav() {
  document.body.classList.remove('menu-open');
  if (menuToggle) menuToggle.setAttribute('aria-expanded', 'false');
  if (navPanel)   navPanel.classList.remove('open');
}

function openNav() {
  document.body.classList.add('menu-open');
  if (menuToggle) menuToggle.setAttribute('aria-expanded', 'true');
  if (navPanel)   navPanel.classList.add('open');
}

if (menuToggle && navPanel) {
  menuToggle.addEventListener('click', () => {
    const isOpen = navPanel.classList.contains('open');
    isOpen ? closeNav() : openNav();
  });
}

// Close nav when a link is clicked
navLinks.forEach(link => {
  link.addEventListener('click', () => {
    closeNav();
  });
});

// Close nav when clicking outside
document.addEventListener('click', (e) => {
  if (
    navPanel &&
    navPanel.classList.contains('open') &&
    !navPanel.contains(e.target) &&
    (!menuToggle || !menuToggle.contains(e.target))
  ) {
    closeNav();
  }
}, true);

// Close nav on escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeNav();
});

/* ── Active Nav Link on Scroll ───────────────────────────────── */
const sections  = document.querySelectorAll('main section[id]');
const allLinks  = document.querySelectorAll('.nav-links a');

const navObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        allLinks.forEach(a => {
          a.classList.toggle('active', a.getAttribute('href') === `#${id}`);
        });
      }
    });
  },
  { rootMargin: '-30% 0px -60% 0px', threshold: 0 }
);

sections.forEach(s => navObserver.observe(s));

/* ── Reveal on Scroll ────────────────────────────────────────── */
const revealEls = document.querySelectorAll('.reveal');

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { rootMargin: '0px 0px -60px 0px', threshold: 0.08 }
);

revealEls.forEach((el, i) => {
  el.style.transitionDelay = `${Math.min(i * 0.04, 0.3)}s`;
  revealObserver.observe(el);
});

/* ── Delivery Card Entrance ──────────────────────────────────── */
const deliveryCards = document.querySelectorAll('.delivery-card');

const cardObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        cardObserver.unobserve(entry.target);
      }
    });
  },
  { rootMargin: '0px 0px -40px 0px', threshold: 0.05 }
);

deliveryCards.forEach(card => cardObserver.observe(card));

/* ── Testimonials Carousel ───────────────────────────────────── */
const viewport  = document.querySelector('[data-testimonials-track]')?.parentElement;
const track     = document.querySelector('[data-testimonials-track]');
const prevBtn   = document.querySelector('[data-carousel-prev]');
const nextBtn   = document.querySelector('[data-carousel-next]');
const dotsWrap  = document.querySelector('.testimonials-dots');

if (viewport && track) {
  const cards = Array.from(track.querySelectorAll('.testimonial-card'));
  let currentIndex = 0;

  // Build dots for mobile
  function buildDots() {
    if (!dotsWrap) return;
    dotsWrap.innerHTML = '';
    const isMobile = window.innerWidth <= 820;
    if (!isMobile) return;
    const visibleCount = Math.max(1, Math.ceil(cards.length / 3));
    for (let i = 0; i < Math.min(visibleCount, cards.length); i++) {
      const dot = document.createElement('span');
      dotsWrap.appendChild(dot);
    }
    updateDots();
  }

  function updateDots() {
    if (!dotsWrap) return;
    const dots = dotsWrap.querySelectorAll('span');
    const total = cards.length;
    const activeDot = Math.round((currentIndex / Math.max(total - 1, 1)) * Math.max(dots.length - 1, 0));
    dots.forEach((d, i) => d.classList.toggle('active', i === activeDot));
  }

  function getScrollStep() {
    // One card width + gap
    const firstCard = cards[0];
    if (!firstCard) return 300;
    const style = getComputedStyle(track);
    const gap = parseFloat(style.gap) || 18;
    return firstCard.offsetWidth + gap;
  }

  function scrollTo(index) {
    const total = cards.length;
    currentIndex = Math.max(0, Math.min(index, total - 1));
    const step = getScrollStep();
    viewport.scrollTo({ left: currentIndex * step, behavior: 'smooth' });
    if (prevBtn) prevBtn.disabled = currentIndex === 0;
    if (nextBtn) nextBtn.disabled = currentIndex >= total - 1;
    updateDots();
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => scrollTo(currentIndex - 1));
  }
  if (nextBtn) {
    nextBtn.addEventListener('click', () => scrollTo(currentIndex + 1));
  }

  // Update current index on manual scroll
  let scrollTimer;
  viewport.addEventListener('scroll', () => {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      const step = getScrollStep();
      currentIndex = Math.round(viewport.scrollLeft / step);
      if (prevBtn) prevBtn.disabled = currentIndex === 0;
      if (nextBtn) nextBtn.disabled = currentIndex >= cards.length - 1;
      updateDots();
    }, 80);
  }, { passive: true });

  // Touch swipe support
  let touchStartX = 0;
  let touchStartScrollLeft = 0;

  viewport.addEventListener('touchstart', (e) => {
    touchStartX = e.touches[0].clientX;
    touchStartScrollLeft = viewport.scrollLeft;
  }, { passive: true });

  viewport.addEventListener('touchend', (e) => {
    const deltaX = touchStartX - e.changedTouches[0].clientX;
    const step = getScrollStep();
    if (Math.abs(deltaX) > step * 0.25) {
      scrollTo(deltaX > 0 ? currentIndex + 1 : currentIndex - 1);
    }
  }, { passive: true });

  // Keyboard support
  viewport.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') scrollTo(currentIndex + 1);
    if (e.key === 'ArrowLeft')  scrollTo(currentIndex - 1);
  });

  // Initialize
  buildDots();
  scrollTo(0);

  // Rebuild dots on resize
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(buildDots, 200);
  }, { passive: true });
}

/* ── 3D Tilt on Delivery Cards (desktop only) ────────────────── */
function initTilt() {
  if (window.innerWidth < 820) return; // Skip on mobile

  deliveryCards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width  - 0.5) * 12;
      const y = ((e.clientY - rect.top)  / rect.height - 0.5) * -12;
      card.style.transform = `perspective(600px) rotateY(${x}deg) rotateX(${y}deg) translateY(-6px) scale(1.01)`;
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
}

initTilt();

/* ── Project Modal ───────────────────────────────────────────── */
const modal      = document.getElementById('project-modal');
const modalClose = modal?.querySelector('.modal-close');
const modalTag   = modal?.querySelector('.modal-tag');
const modalTitle = modal?.querySelector('.modal-title');
const modalDesc  = modal?.querySelector('.modal-description');
const modalFeats = modal?.querySelector('.modal-features ul');
const modalImpct = modal?.querySelector('.modal-impact ul');
const modalPrev  = modal?.querySelector('.modal-preview');
const modalPrevI = modal?.querySelector('.modal-preview-img');

const projectData = {
  "OfficePulse (Web App)": {
    tag: "Workforce Management",
    description: "A centralized workforce management system built to streamline HR operations for growing companies. OfficePulse Web provides managers and employees with a unified platform for tracking attendance, managing tasks, and generating data-driven insights.",
    features: ["Real-time attendance & leave management", "Task tracking system with assignments", "Holiday management calendar", "Reports & analytics dashboard", "Role-based access controls", "Employee self-service portal"],
    impact: ["Reduced manual HR workload by up to 60%", "Centralized data for better decision-making", "Improved team accountability and transparency", "Scalable for teams of 10 to 1000+"]
  },
  "OfficePulse (Android App)": {
    tag: "Mobile",
    description: "The mobile extension of OfficePulse, designed to give employees and managers full access to workforce management features from their smartphones. Built for Android with a focus on speed, reliability, and ease of use.",
    features: ["Real-time attendance tracking via mobile", "Task updates & push notifications", "Leave request and approval workflow", "Mobile dashboard access", "Offline-capable core features", "Biometric check-in support"],
    impact: ["Enabled field teams to stay connected", "Reduced attendance discrepancies by 45%", "Improved leave approval turnaround time", "Higher employee adoption vs desktop-only tools"]
  },
  "Task Orbit (Android App)": {
    tag: "Productivity",
    description: "A feature-rich task management Android application designed to help teams stay organized, meet deadlines, and collaborate effectively. Task Orbit brings clarity to complex workflows through intuitive task structures and real-time team visibility.",
    features: ["Task creation & team assignment", "Progress tracking with status updates", "Deadline notifications & smart reminders", "Team collaboration tools", "Priority tagging system", "Project-level reporting"],
    impact: ["Reduced missed deadlines by 35%", "Improved cross-team visibility and accountability", "Higher team productivity scores after adoption", "Simplified project handoffs between team members"]
  },
  "My EduMate (Web App)": {
    tag: "EdTech",
    description: "A smart school management system designed to simplify day-to-day administration for educational institutions. My EduMate replaces manual processes with automated workflows for attendance, reporting, and student records management.",
    features: ["Student attendance tracking system", "Admin dashboard with overview metrics", "Automated report generation", "School-specific workflow customization", "Parent & teacher communication tools", "Academic calendar management"],
    impact: ["Cut administrative workload by 50%+", "Improved attendance record accuracy", "Faster report generation for management", "Better parent engagement through transparency"]
  },
  "LMS Web App": {
    tag: "EdTech",
    description: "A scalable learning management system built for educational institutions and corporate training teams. The LMS provides a comprehensive platform for course creation, delivery, and performance tracking across diverse learner groups.",
    features: ["Course creation & content management", "Student progress tracking & analytics", "Multi-format content delivery system", "User roles & granular access control", "Assessment & quiz builder", "Certificate generation"],
    impact: ["Enabled fully digital course delivery", "Improved learner completion rates by 40%", "Reduced training administration overhead", "Scalable from 50 to 50,000+ learners"]
  },
  "LuxeVoyage Luxury Travel Booking Platform": {
    tag: "Travel Tech",
    description: "A premium end-to-end travel booking platform designed to simplify trip planning and deliver a seamless, luxurious experience for travelers. LuxeVoyage combines intuitive UX with powerful backend systems to make complex itinerary building effortless.",
    features: ["Curated luxury travel packages", "Real-time availability & booking engine", "Multi-destination itinerary planning", "Concierge service integration", "Secure payment processing", "Post-booking trip management"],
    impact: ["Streamlined the booking journey from 12 steps to 4", "Increased conversion rates vs legacy systems", "Premium brand positioning in competitive market", "High repeat booking rate due to seamless UX"]
  },
  "CloudOps Console": {
    tag: "Cloud",
    description: "An infrastructure management panel built for engineering and DevOps teams. CloudOps Console provides a unified view of deployment pipelines, uptime metrics, and release coordination to keep systems running smoothly.",
    features: ["Deployment pipeline visibility", "Uptime monitoring & alerts", "Release coordination tools", "Environment management dashboard", "Log aggregation & search", "Team-based access controls"],
    impact: ["Reduced mean time to detect (MTTD) incidents", "Improved release confidence and rollback speed", "Single pane of glass for distributed infrastructure", "Better cross-team coordination during deployments"]
  },
  "TalentSync HR Hub": {
    tag: "HR Tech",
    description: "A people operations platform that brings hiring, employee records, and internal workflow automation into one unified system. TalentSync HR Hub helps HR teams move faster and make better decisions with structured data and automation.",
    features: ["End-to-end hiring pipeline management", "Employee records & document storage", "Internal workflow automation", "Onboarding checklist system", "Performance review tracking", "HR analytics dashboard"],
    impact: ["Cut time-to-hire by 30%", "Eliminated manual paperwork across HR operations", "Improved new hire onboarding experience", "Better data compliance and audit readiness"]
  },
  "Business Website Development Solutions": {
    tag: "Web Development",
    description: "High-performance website development for tech companies, consultancies, and industrial businesses. Each site is crafted with a focus on modern design, lead generation optimization, and long-term maintainability.",
    features: ["Modern responsive UI/UX design", "Service-focused page layouts", "Lead generation & conversion optimization", "Fast-loading performance-first build", "SEO-ready code structure", "CMS integration for easy content updates"],
    impact: ["Improved organic search visibility for clients", "Higher lead conversion rates vs previous sites", "Positive brand perception uplift", "Reduced bounce rates through better UX"]
  },
  "HR Consultancy & Organizational Setup": {
    tag: "HR Consulting",
    description: "A comprehensive HR consultancy solution that helps growing businesses build the foundational systems they need to scale their teams effectively. From policy creation to organizational design, we structure HR from the ground up.",
    features: ["HR policy development & documentation", "Organizational structure design", "Compliance framework setup", "Employee handbook creation", "Performance management system setup", "HR process standardization"],
    impact: ["Enabled businesses to scale from 5 to 50+ employees", "Reduced HR-related compliance risks", "Created clear career paths that improved retention", "Established repeatable hiring processes"]
  },
  "Talent Acquisition & Recruitment Solutions": {
    tag: "Recruitment",
    description: "A focused recruitment solution to help businesses identify, attract, and onboard the right talent efficiently. We handle the full recruitment lifecycle so your team can focus on building great products.",
    features: ["Job description optimization", "Multi-channel candidate sourcing", "Structured interview process design", "Candidate evaluation frameworks", "Offer management & negotiation", "Onboarding coordination"],
    impact: ["Reduced average time-to-fill by 35%", "Higher candidate quality and culture fit", "Lower early attrition in placed candidates", "Saved hundreds of hiring manager hours"]
  },
  "End-to-End Staffing Solutions": {
    tag: "Staffing",
    description: "A scalable staffing solution that enables businesses to build and manage teams without the operational complexity of traditional recruitment. Ideal for growing companies that need talent fast without sacrificing quality.",
    features: ["Bulk and specialist hiring support", "Contract & permanent staffing", "Background verification coordination", "Payroll & compliance management", "Replacement guarantee program", "Dedicated account management"],
    impact: ["Built entire departments from scratch for clients", "Reduced cost-per-hire vs agency-led approaches", "Provided continuity through rapid growth phases", "Enabled businesses to enter new markets quickly"]
  },
  "Workforce Optimization & HR Support": {
    tag: "HR Support",
    description: "A strategic HR support solution focused on improving workforce productivity and operational efficiency. We embed alongside your team to identify bottlenecks, optimize processes, and build a high-performance culture.",
    features: ["Workforce productivity assessment", "Process bottleneck identification", "Performance metric framework", "Manager coaching & enablement", "Team restructuring support", "HR KPI reporting"],
    impact: ["Average 25% productivity improvement post-engagement", "Improved employee satisfaction scores", "Reduced management overhead through better systems", "Clearer accountability across teams"]
  },
  "AI & Emerging Technologies Training Program": {
    tag: "Training",
    description: "A hands-on training program designed to introduce learners to real-world applications of artificial intelligence and emerging technologies. Built for students, professionals, and teams who want to stay ahead of the technology curve.",
    features: ["Practical AI application modules", "Machine learning fundamentals", "Prompt engineering & LLM usage", "Real-world project assignments", "Industry use case workshops", "Certification upon completion"],
    impact: ["Trained 200+ learners across cohorts", "90%+ satisfaction score from participants", "Participants secured AI-adjacent roles post-training", "Bridged the gap between theory and real application"]
  },
  "Data Analysis & Insights Program": {
    tag: "Analytics",
    description: "A structured training program focused on developing analytical thinking and data-driven decision-making skills. Participants work with real datasets and industry tools to build practical, job-ready capabilities.",
    features: ["Spreadsheet & data modeling foundations", "SQL for data querying", "Data visualization with real tools", "Statistical thinking modules", "Business case analysis", "Dashboard creation projects"],
    impact: ["Helped participants move into analytics roles", "Real dataset projects built confidence", "Improved data literacy across participating organizations", "Structured curriculum delivered measurable skill gains"]
  },
  "Web Development & Practical Coding Program": {
    tag: "Development",
    description: "A practical training program aimed at building strong fundamentals in web development through hands-on implementation. Designed for beginners and career changers looking to enter the technology industry.",
    features: ["HTML, CSS & JavaScript fundamentals", "Responsive design principles", "Frontend framework introduction", "Backend basics & APIs", "Git & version control", "Portfolio project development"],
    impact: ["Multiple participants secured developer internships", "Built job-ready portfolios during the program", "High completion rate due to hands-on structure", "Reduced learning curve for career changers"]
  },
  "Career-Focused Technical Training Initiative": {
    tag: "Career Training",
    description: "A career-oriented training initiative designed to prepare individuals with industry-relevant skills and practical exposure. Combines technical learning with career development support for a complete launchpad experience.",
    features: ["Industry-aligned technical curriculum", "Resume & LinkedIn profile optimization", "Mock interview preparation", "Industry mentor connections", "Live project experience", "Job search strategy coaching"],
    impact: ["70%+ placement rate within 90 days of completion", "Participants reported higher interview confidence", "Strong industry feedback on graduate readiness", "Partnerships with hiring companies for direct placement"]
  },
  "Corporate Portfolio Development": {
    tag: "Web Design",
    description: "Professional portfolio website development for businesses that want to make a strong first impression online. Each corporate portfolio is designed to reflect brand identity, showcase capabilities, and generate qualified inquiries.",
    features: ["Modern UI/UX design from scratch", "Responsive multi-device layouts", "Brand-aligned visual identity", "Content architecture & copywriting support", "Case study & project showcase sections", "Contact & inquiry optimization"],
    impact: ["Improved professional credibility for clients", "Higher quality inbound inquiries post-launch", "Consistent brand representation across touchpoints", "Fast turnaround from brief to live site"]
  },
  "Author & Writer Portfolio Platforms": {
    tag: "Creative",
    description: "Elegant portfolio websites crafted specifically for authors and writers. These platforms are built to showcase written work, build a personal brand, and connect writers with their audience in a clean, distraction-free environment.",
    features: ["Content-focused minimalist layouts", "Blog & article showcase integration", "Personal branding design system", "Clean, premium reading experience", "Book or publication spotlight sections", "Newsletter & contact integration"],
    impact: ["Enhanced online presence for independent writers", "Increased reader engagement and return visits", "Professional presentation that opened new opportunities", "Writers gained speaking and collaboration invitations"]
  }
};

function openModal(cardTitle, cardElement) {
  const key = Object.keys(projectData).find(k =>
    cardTitle.toLowerCase().includes(k.toLowerCase().slice(0, 15))
  ) || Object.keys(projectData).find(k =>
    k.toLowerCase().includes(cardTitle.toLowerCase().slice(0, 15))
  );

  const data = projectData[key];
  if (!data || !modal) return;

  if (modalTag)   modalTag.textContent   = data.tag;
  if (modalTitle) modalTitle.textContent = key;
  if (modalDesc)  modalDesc.textContent  = data.description;

  if (modalFeats) {
    modalFeats.innerHTML = data.features.map(f => `<li>${f}</li>`).join('');
  }
  if (modalImpct) {
    modalImpct.innerHTML = data.impact.map(i => `<li>${i}</li>`).join('');
  }

  const cardImg = cardElement?.querySelector('.delivery-thumb img');
  if (modalPrev && modalPrevI) {
    if (cardImg?.getAttribute('src')) {
      modalPrevI.src = cardImg.getAttribute('src');
      modalPrevI.alt = cardImg.getAttribute('alt') || `${key} preview`;
      modalPrev.classList.remove('is-hidden');
      modalPrev.setAttribute('aria-hidden', 'false');
    } else {
      modalPrevI.removeAttribute('src');
      modalPrevI.alt = '';
      modalPrev.classList.add('is-hidden');
      modalPrev.setAttribute('aria-hidden', 'true');
    }
  }

  modal.classList.add('active');
  document.body.style.overflow = 'hidden';

  // Focus trap focus close button
  setTimeout(() => modalClose?.focus(), 50);
}

function closeModal() {
  if (!modal) return;
  modal.classList.remove('active');
  document.body.style.overflow = '';
}

deliveryCards.forEach(card => {
  card.addEventListener('click', () => {
    const h3 = card.querySelector('h3');
    if (h3) openModal(h3.textContent.trim(), card);
  });

  // Keyboard accessible
  card.setAttribute('tabindex', '0');
  card.setAttribute('role', 'button');
  card.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      const h3 = card.querySelector('h3');
      if (h3) openModal(h3.textContent.trim(), card);
    }
  });
});

if (modalClose) {
  modalClose.addEventListener('click', closeModal);
}

if (modal) {
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && modal?.classList.contains('active')) closeModal();
});
